function varargout=searchImage(paramsFile,varargin);
% search an image for a structure and save results in several forms
%
% paramsFile is the path to an ASCII file that expects inputs
% in the following format: 
% 
% outputDir testDir
% imageFile /groups/denk/home/rickgauerj/images/search/100314_0001_search.mrc
% modelFile /groups/denk/home/rickgauerj/models/2W0O/2W0O_0001_SP.mrc
% aPerPix 0.970
% defocus 68.0489 65.5753 -0.1402
% MTF 0 0.9350 0 0 0.6400
% arbThr 5
% rotationsFile rotations/hopf_R5.txt
% psdFilterFlag 1
% Cs 0.0027
% Cc 0.0027
% deltaE 0.7
% V_acc 300000
% a_i 0.000050
% binRange 15
%
% function varargout=searchImage(paramsFile,varargin);

% read params file:
global params

params=struct('outputDir',[],'listFormat','dat','imageFile',[],'modelFile',[],'maskFile',[],'aPerPix',1.0,'defocus',[70 70 0], ...
    'MTF',[0 0.935 0 0 0.64],'arbThr',[],'highThr',[],'nCores',8,'rotationsFile',[], ...
    'F_abs',0,'psdFilterFlag',1,'sectors',[],'Cs',0.0027,'Cc',0.0027,'V_acc',300, ...
    'deltaE',0.7,'a_i',50e-6,'binRange',15,'nBins',1024);

%
% read in parameters from file

% global params
try
    readParamsFile(paramsFile);
catch
    fprintf('Error reading parameters file...\n');
    return;
end;
jobNum=1;
if( nargin>1 )
    jobNum=str2num(varargin{1});
end;

scratchDir=fullfile(params.outputDir,'scratch');
if( exist(params.outputDir,'dir')~=7 )
    fprintf('Making new project directory... [%s]\n',params.outputDir);
    mkdir(params.outputDir);
end;
if( exist(scratchDir,'dir')~=7 )
    fprintf('Making new scratch directory... [%s]\n',scratchDir);
    mkdir(scratchDir);
end;

disp(datestr(now));
fileNum=jobNum;
fnLog=[scratchDir '/output_' zp(jobNum,4) '.txt'];
fprintf('Making new logfile... [%s]\n',fnLog);
fidLog=fopen(fnLog,'w');
fprintf(fidLog,'%s\n',datestr(now,31));

fileBase='search_';
fNumPadded=zp(num2str(fileNum),4);

searchDir=[scratchDir '/'];
outputDir=[params.outputDir '/'];
R=readRotationsFile(params.rotationsFile);

nIndices=size(R,3);
R_inds=assignJobs(nIndices,params.nCores,jobNum);
rotationsPerFile=length(R_inds);
nRotations=rotationsPerFile;
fileMultiplier=R_inds(1)-1;
fprintf(fidLog,'job indices: [%s:%s]\n',num2str(R_inds(1)),num2str(R_inds(end)));
fprintf('job indices: [%s:%s]\n',num2str(R_inds(1)),num2str(R_inds(end)));

nRotations_full=size(R,3);

ccFlag=1;
if( isempty(params.imageFile) )
    ccFlag=0;
end;


pv=zeros(nRotations,1);
pl=zeros(nRotations,1);
fprintf(fidLog,'\nJob %i of %i, including %i rotations...\n',jobNum,params.nCores,nRotations);
disp(params);

if( ccFlag )
    % padding:
    imref_orig=mr(params.imageFile);
    minDim=min(size(imref_orig));
    imref=cutj(imref_orig,[minDim,minDim]);
    imref=cropForFFT(imref);
    imref=nm(imref);
    Npix_im=size(imref,1);    
    if( ~isempty(params.maskFile) )
        if( exist(params.maskFile,'file')==2 )
            mask_im=mr(params.maskFile);
            Npix_mask=sqrt(length(find(mask_im(:)==1)));
            mask_im=cropForFFT(mask_im);
            fprintf(fidLog,'using mask in %s with %7.0d pixels...\n', ...
            params.maskFile,length(find(mask_im(:)==1)));            
        else
            mask_im=ones(size(imref,1),size(imref,2));
            Npix_mask=size(imref,1);
            fprintf(fidLog,'could not find specified mask file %s...\n',params.maskFile);
        end;
    else
        mask_im=ones(size(imref,1),size(imref,2));
        Npix_mask=size(imref,1);
        fprintf(fidLog,'no mask specified for search image...\n');
    end;
    
    if( params.psdFilterFlag )
        try
            fprintf(fidLog,'calculating PSD filter...\n');
            [fPSD,~,~]=psdFilter(imref,'sqrt',params.sectors);
        catch            
            fprintf(fidLog,'could not find PSD filter...\n');
            fprintf(fidLog,'not applying PSD filter...\n');
            fPSD=ones(size(imref,1),size(imref,2),'single');
            fPSD=resize_F(fPSD,size(imref,1)/size(fPSD,1),'newSize');
        end;
        fPSD=ifftshift(fPSD);
        fPSD(1,1)=0;
        fPSD=fftshift(fPSD);
    else
        fprintf(fidLog,'not applying PSD filter...\n');
        fPSD=ones(size(imref,1),size(imref,2),'single');
        fPSD=resize_F(fPSD,size(imref,1)/size(fPSD,1),'newSize');
        fPSD=ifftshift(fPSD);
        fPSD(1,1)=0;
        fPSD=fftshift(fPSD);
    end;
    
    imref=iftj(ftj(imref).*fPSD);
    imref=nm(imref);
    fPSD=ifftshift(fPSD);
    % if this is the first job, save a copy of the filtered image:
    if( fileNum==1 )
        mw(single(imref),[outputDir 'searchImage.mrc'],params.aPerPix);
    end;
    
    disp(['using image with ' num2str(Npix_im) '^2 pixels']);
    fullX=size(imref,1); fullY=size(imref,2);
    fullXY=fullX*fullY;
    imref_F=fftn(ifftshift(nm(imref)));
    
end; % if( ccFlag )

%
% read in the scattering potential and forward transform (leave origin at center):
disp('reading SPV...');
SPV=mr(params.modelFile);
Npix=min(size(SPV));
V=SPV+1i*params.F_abs*SPV;
V_F=double(fftshift(fftn(ifftshift(V))));
V_Fr=double(real(V_F));
V_Fi=double(imag(V_F));
clear SPV V V_F;

binRange=params.binRange;
nBins=params.nBins;
bins=linspace(-binRange,binRange,nBins);
N=zeros(nBins,1);

%
% % work out re-indexing matrices equivalent to small and large 
% % fftshifts in advance:
% fftshift:
idx_large_f = cell(1,2);
for k = 1:2
    m = fullX;
    p = ceil(m/2);
    idx_large_f{k} = single([p+1:m 1:p]);
end;
idx_small_f = cell(1,2);
for k = 1:2
    m = Npix;
    p = ceil(m/2);
    idx_small_f{k} = [p+1:m 1:p];
end;

% ifftshift:
idx_large_i = cell(1,2);
for k = 1:2
    m = fullX;
    p = floor(m/2);
    idx_large_i{k} = single([p+1:m 1:p]);
end;
idx_small_i = cell(1,2);
for k = 1:2
    m = Npix;
    p = floor(m/2);
    idx_small_i{k} = [p+1:m 1:p];
end;

[k_2d,cp]=getKs(Npix,params.aPerPix);
[x,y,z]=meshgrid(1:Npix,1:Npix,1:Npix);
x0=x(:,:,cp)-cp;
y0=y(:,:,cp)-cp;
z0=zeros(Npix,Npix);
xyz=[x0(:) y0(:) z0(:)];
dummyX=1:size(V_Fr,1); dummyY=1:size(V_Fr,2); dummyZ=1:size(V_Fr,3);
clear x y z x0 y0 z0;

CTF=ctf(Npix);
MTF=approxMTF(k_2d,params.MTF);
MTFCTF=MTF.*CTF;
MTFCTF=ifftshift(MTFCTF);

fnDone=[searchDir fileBase '_' fNumPadded '.dat'];

R=double(R(:,:,R_inds));

allNewVals=0;
arbVals=[];


if( ccFlag )
    % % calculate the expected value away from one unrotated template:
    X=xyz(:,1)+cp; Y=xyz(:,2)+cp; Z=xyz(:,3)+cp;
    output_image = complex(ba_interp3(V_Fr,X,Y,Z,'cubic'),ba_interp3(V_Fi,X,Y,Z,'cubic'));
    vi_rs=reshape(output_image,Npix,Npix); 
    vi_rs(find(isnan(vi_rs)==1))=0;
    projPot=vi_rs;
    projPot=real(ifftn(projPot(idx_small_i{:})));
    ew=exp(1i.*projPot(idx_small_f{:}));    
    ew=ew(idx_small_i{:});
    ew=fftn(ew);
    ew=ew.*MTFCTF;
    ew=ifftn(ew);
    w_det=ew(idx_small_f{:});
    template=single(real(w_det.*conj(w_det)));
    temp=rrj(zeros(Npix,Npix));
    rMask=nan(Npix,Npix);
    rMask(find(temp>0.5))=1;
    temp=template.*rMask;
    bgVal=single(nanmedian(temp(:)));

    % % work out the shifts for padding templates out just once:
    xDim=fullX; yDim=fullY;
    oldDim=[(Npix) (Npix)];
    newDim=[(xDim) (yDim)];
    halfOldDim=[]; halfNewDim=[]; centerPixOld=[]; centerPixNew=[];
    for i=1:2
        oddOldFlag=mod(oldDim(i),2);
        if( oddOldFlag==1 )
            halfOldDim(i)=ceil(oldDim(i)./2);
            halfNewDim(i)=floor(newDim(i)./2);
            centerPixOld(i)=halfOldDim(i);
            centerPixNew(i)=halfNewDim(i)+1;
        else
            halfOldDim(i)=oldDim(i)./2;
            halfNewDim(i)=newDim(i)./2;
            centerPixOld(i)=halfOldDim(i)+1;
            centerPixNew(i)=floor(halfNewDim(i)+1);
        end;
        edges{i}=[centerPixOld(i)-newDim(i)./2 centerPixOld(i)+(newDim(i)./2)-1];
    end;
    diffSize=newDim(1)-oldDim(1);
    rowColInds={ [num2str(centerPixNew(1)-oldDim(1)./2) ':' num2str((centerPixNew(1)+oldDim(1)./2)-1)] , ...
        [num2str(centerPixNew(2)-oldDim(2)./2) ':' num2str((centerPixNew(2)+oldDim(2)./2)-1)] };
    dummy=reshape(1:(xDim)*(yDim),(xDim),(yDim));
    eval(['rowColNums=dummy(' rowColInds{1} ',' rowColInds{2} ');']);
    
    
    mip=ones(Npix_im,Npix_im,'single').*-1000;
    mipi=ones(Npix_im,Npix_im,'single').*-1000;
    sum1=zeros(Npix_im,Npix_im,'single');
    sum2=zeros(Npix_im,Npix_im,'single');    
    temp_image=zeros(fullX,fullY,'single');

    fprintf(fidLog,'computing xcorrs...\n'); tic;
else
    fprintf(fidLog,'making templates (no image to search)...\n'); 
    templates=zeros(Npix,Npix,nRotations,'single');
    tic;
end; % if( ccFlag )

nfp=1;
highVals=[]; 
if( isempty(params.highThr) )
    highThr=sqrt(2).*erfcinv(nfp.*2./(fullX.*fullY.*nRotations_full))
end;
dummyVec=1:(fullX*fullY);
dummyIm=reshape(dummyVec,[fullX fullY]);

%
% generate templates and cross-correlate them with the image:

for i=1:nRotations    
    
    
    qInd=fileMultiplier+i;    
    RM=R(:,:,i)';
    xyz_r=(RM*xyz')';    
    X=xyz_r(:,1)+cp; Y=xyz_r(:,2)+cp; Z=xyz_r(:,3)+cp;
    output_image = complex(ba_interp3(V_Fr,X,Y,Z,'cubic'),ba_interp3(V_Fi,X,Y,Z,'cubic'));
    vi_rs=reshape(output_image,Npix,Npix); 
    vi_rs(find(isnan(vi_rs)==1))=0;
    projPot=vi_rs;
    projPot=real(ifftn(projPot(idx_small_i{:})));
    ew=exp(1i.*projPot(idx_small_f{:}));    
    ew=ew(idx_small_i{:});
    ew=fftn(ew);
    ew=ew.*MTFCTF;
    ew=ifftn(ew);
    w_det=ew(idx_small_f{:});
    template=single(real(w_det.*conj(w_det))); % detector image
    
    if( ccFlag )
        
        template=template-bgVal;
        temp_image(rowColNums)=template; % place in padded image
    	template_F=fftn(temp_image(idx_large_i{:}));

        template_F=template_F.*fPSD; % filter (whiten) if called for
        
        templateVec=template_F(:); % normalize
        v=sum(abs(templateVec).^2,1,'native');
        v=v./fullXY;
        template_F=template_F./sqrt(v./fullXY);
        template_F=conj(template_F);      

        cc_F=imref_F.*(template_F); % cross-correlate        
        cc=ifftn(cc_F);
        cc=cc(idx_large_f{:});
        cc=real(cc);
        
        cc=cc./Npix_im;
        cc=cc.*mask_im;

        [pv(i),pl(i)]=max(cc(:)); % rotation-indexed list
        sum1=sum1+cc; % first moment
        sum2=sum2+cc.^2; % second moment
        inds=(cc>mip);
        mip(inds)=(cc(inds)); % max intensity projection (MIP)
        mipi(inds)=qInd; % MIP rotation indices
        temp=cc>params.arbThr; 
        newVals=cc(temp);
        nNewVals=length(newVals);
        newLocs=single(find(temp));
        newInds=repmat(qInd,nNewVals,1);        
        newVals_all=single([newVals newLocs newInds]);
        arbVals{i}=newVals_all; % values above the specified threshold
        
        cc=(cc./(2.*binRange))+0.5;
        N_new=imhist(cc(:),nBins);
        N=N+N_new; % histogram
        highVals=[highVals; newVals_all((newVals_all(:,1)>highThr),:)];
    else
        templates(:,:,i)=template;
    end; % if( ccFlag )
    
    if( mod(i,10)==0 )
        fprintf(fidLog,'.');
        if( mod(i,100)==0 )
            fprintf(fidLog,'\n%d/%d ',i,nRotations);
            fprintf(fidLog,'averaging %3.0f msec. per orientation',1000.*toc./100);
            fprintf('\n%d/%d ',i,nRotations);
            fprintf('averaging %3.0f msec. per orientation',1000.*toc./100);
            if( mod(i,10000)==0 )
                if( ~isempty( highVals ) )
                    [a,b]=ind2sub([fullX fullY],highVals(:,2));
                    highLocs=[a b];
                    list_highVals=[highVals(:,3) highVals(:,1) a b]; % index, value, row, col
                    fid=fopen([outputDir 'highVals_' fNumPadded '.txt'],'w');
                    for i=1:size(list_highVals,1)
                        fprintf(fid,'%i\t%8.3f\t%i\t%i\n',list_highVals(i,:));
                    end;
                    fclose(fid);
                end;
            end;
            tic;
        end;
    end;
end;
timeElapsed=toc;
fprintf(fidLog,'%8.2f seconds to complete.\n',timeElapsed);
disp(datestr(now));

%
% write the output files:

if( ccFlag )
    fn_mip=[searchDir fileBase fNumPadded '_mip.mrc'];
    fn_mipi=[searchDir fileBase fNumPadded '_mipi.mrc'];
    fn_sum1=[searchDir fileBase fNumPadded '_sum.mrc'];
    fn_sum2=[searchDir fileBase fNumPadded '_ssum.mrc'];
    fn_list=[searchDir fileBase fNumPadded '_list.dat'];
    fn_arb=[searchDir fileBase fNumPadded '_arb.dat'];
    fn_hist=[searchDir fileBase fNumPadded '_hist.dat'];
    
    mw(single(mip),fn_mip,params.aPerPix);
    mw(single(mipi),fn_mipi,params.aPerPix);
    mw(single(sum1),fn_sum1,params.aPerPix);
    mw(single(sum2),fn_sum2,params.aPerPix);
    
    fid=fopen(fn_list,'w');
    fwrite(fid,single(reshape([pv pl]',1,2.*length(pv))),'single');
    fclose(fid);
    
    fid=fopen(fn_hist,'w');
    fwrite(fid,N,'int64');
    fclose(fid);
    
    arbV=[];
    for i=1:nRotations
        arbV=[arbV; arbVals{i}];
    end;
    fid=fopen(fn_arb,'w');
    fwrite(fid,single(reshape(arbV',1,size(arbV,1)*3)),'single');
    fclose(fid);
    
else
    fn_templates=[searchDir fileBase fNumPadded '_templates.mrc'];
    mw(single(templates),fn_templates,params.aPerPix);
end;


fprintf(fidLog,'Done with job %i at %s\n',jobNum,datestr(now,31));

% 
% combine output and clean up:

if( fileNum==params.nCores )
    
if( ccFlag )
    fileTypesExpected={'mip','mipi','list','arb','sum','ssum','hist'};
else
    fileTypesExpected={'templates'};
end;

while 1
    % % get a list of existing files to combine and do sanity check:
    nFilesExpected=params.nCores;
    fprintf(fidLog,'Looking for files from %i searches...\n',nFilesExpected);
    
    numFound=[]; fileTypesFound={};
    A=dir([searchDir 'search_*.*']);
    ctr=1;
    for i=1:length(A)
        tempNum=regexp(A(i).name,'search_(\d{4,4})_','tokens');
        if( length(tempNum)>0 )
            numFound(ctr)=str2num(char(tempNum{1}));
            tempType=regexp(A(i).name,'search_(\d{4,4})_','split');
            tempTypeParts=regexp(tempType{2},'(\.{1,1})','split');
            fileTypesFound{ctr}=tempTypeParts{1};
            ctr=ctr+1;
        end;
    end;
    
    if( ctr>(nFilesExpected.*length(fileTypesExpected)) )
        fprintf(fidLog,'combining %i files...\n',(nFilesExpected.*length(fileTypesExpected)));
        if( params.nCores>1 )
            pause(10);
        end;
        break;
    end;
    pause(1);
end;

inds={};
for i=1:length(fileTypesExpected)
    inds{i}=find(strcmp(fileTypesFound,fileTypesExpected{i})==1);
end;

temp=mr([searchDir A(inds{1}(1)).name]);
if( ccFlag )
    mip_group=zeros(size(temp,1),size(temp,2));
    mipi_group=zeros(size(temp,1),size(temp,2));
    sumImage_group=zeros(size(temp,1),size(temp,2));
    ssumImage_group=zeros(size(temp,1),size(temp,2));
    hist_group=zeros(1,nBins);
    pvl=[]; arbVector=[];
else
    templates_group=zeros(size(temp,1),size(temp,2));
end; % if( ccFlag )

% % read in each file-type and combine:
for i=1:length(inds{1})
    for j=1:length(fileTypesExpected)
        fileType=fileTypesExpected{j};
        fn=[searchDir A(inds{j}(i)).name];
        switch fileType
            case 'mip'
                mip=mr(fn);
                temp=mip>mip_group;
                mip_inds=find(temp==1);
                mip_group(mip_inds)=mip(mip_inds);
            case 'mipi'
                mipi=mr(fn);
                mipi_group(mip_inds)=mipi(mip_inds);
            case 'sum'
                sumImage=mr(fn);
                sumImage_group=sumImage_group+sumImage;
            case 'ssum'
                ssumImage=mr(fn);
                ssumImage_group=ssumImage_group+ssumImage;
            case 'list'
                fid=fopen(fn,'r');
                temp=fread(fid,inf,'single');
                fclose(fid);
                peakVals=temp(1:2:end); peakTemp=temp(2:2:end);
                pv=[peakVals peakTemp];
                pvl=[pvl; pv];
            case 'arb'
                fid=fopen(fn,'r');
                temp=fread(fid,inf,'single');
                fclose(fid);
                arbVals=temp(1:3:end); arbTemp=temp(2:3:end); arbInds=temp(3:3:end);
                av=[arbVals arbTemp arbInds];
                arbVector=[arbVector; av];
            case 'hist'
                fid=fopen(fn,'r');
                N=fread(fid,inf,'int64')';
                fclose(fid);
                temp=reshape(N,1,nBins);
                hist_group=hist_group+temp;
            case 'templates'
                templates=mr(fn);
                templates_group=cat(3,templates_group,templates);
            otherwise
                fprintf(fidLog,'file type %s not recognized...\n',fileType);
        end;
    end;
end;

if( ccFlag )
    dummyVec=1:(size(mip_group,1)*size(mip_group,2));
    dummyIm=reshape(dummyVec,size(mip_group));
    [a,b]=ind2sub(size(dummyIm),pvl(:,2));
    peakLocs=[a b];
    list_byRotation=[pvl(:,1) a b]; % value, row, col
    
    temp=arbTemp; temp(find(temp==0))=1;
    [a,b]=ind2sub(size(dummyIm),arbVector(:,2));
    arbLocs=[a b];
    list_aboveThreshold=[arbVector(:,3) arbVector(:,1) a b]; % index, value, row, col
    
    
    % write combined files:
    fprintf(fidLog,'writing combined files...\n');
    mw(single(mip_group),[outputDir 'search_mip.mrc'],params.aPerPix);
    mw(single(mipi_group),[outputDir 'search_mipi.mrc'],params.aPerPix);
    mw(single(sumImage_group),[outputDir 'search_sumImage.mrc'],params.aPerPix);
    mw(single(ssumImage_group),[outputDir 'search_squaredSumImage.mrc'],params.aPerPix);
    switch params.listFormat
        case 'txt'
            fid=fopen([outputDir 'search_listByRotation.txt'],'w');
            for i=1:size(list_byRotation,1)
                fprintf(fid,'%8.3f\t%i\t%i\n',list_byRotation(i,:));
            end;
            fclose(fid);
            fid=fopen([outputDir 'search_listAboveThreshold.txt'],'w');
            for i=1:size(list_aboveThreshold,1)
                fprintf(fid,'%i\t%8.3f\t%i\t%i\n',list_aboveThreshold(i,:));
            end;
            fclose(fid);
            fid=fopen([outputDir 'search_hist.txt'],'w');
            for i=1:length(hist_group)
                fprintf(fid,'%i\n',hist_group(i));
            end;
            fclose(fid);            
        otherwise
            fid=fopen([outputDir 'search_listByRotation.dat'],'w');
            fwrite(fid,single(reshape([list_byRotation]',1,3.*length(list_byRotation))),'single');
            fclose(fid);

            fid=fopen([outputDir 'search_listAboveThreshold.dat'],'w');
            fwrite(fid,single(reshape(list_aboveThreshold',1,size(list_aboveThreshold,1)*4)),'single');
            fclose(fid);
             
            fid=fopen([outputDir 'search_hist.dat'],'w');
            fwrite(fid,hist_group,'int64');
            fclose(fid);
    end;
else
    fprintf(fidLog,'writing combined templates...\n');
    templates_group=templates_group(:,:,2:end);
    mw(single(templates_group),[outputDir 'search_templates.mrc'],params.aPerPix)
end; % if( ccFlag )

% delete temp files:
fprintf(fidLog,'deleting scratch files...\n');
for i=1:length(inds{1})
    for j=1:length(fileTypesExpected)
        fileType=fileTypesExpected{j};
        fn=[searchDir A(inds{j}(i)).name];
        delete(fn);
    end;
end;

fprintf(fidLog,'Done combining search output at %s\n',datestr(now,31));
fprintf(fidLog,'Consolidating log files...\n');

fclose(fidLog);
fnFinal=[outputDir 'search.log'];
fidFinal=fopen(fnFinal,'w');

tline={''};
for i=1:jobNum
    fn=[searchDir 'output_' zp(i,4) '.txt'];
    try
        fid=fopen(fn,'r');
        while 1
            temp=fgets(fid);
            disp(temp);
            if ~ischar(temp) 
                break; 
            else
                fprintf(fidFinal,temp);
            end;
        end
        fclose(fid);
        delete(fn);
    catch
        tline{end+1}=['could not open ' fn];
        if( exist('fid','var') )
            if( fid>0 )
                fclose(fid);
            end;
        end;
    end;
end;
fprintf(fidFinal,'*****\nFinished at %s\n*****',datestr(now,31));
fclose(fidFinal);
end;




%% functions called:

function readParamsFile(paramsFile);
% read params file

global params

params=struct('outputDir',[],'listFormat','dat','imageFile',[],'modelFile',[],'maskFile',[],'aPerPix',1.0,'defocus',[70 70 0], ...
    'MTF',[0 0.935 0 0 0.64],'arbThr',[],'highThr',[],'nCores',8,'rotationsFile',[], ...
    'F_abs',0,'psdFilterFlag',1,'sectors',[],'Cs',0.0027,'Cc',0.0027,'V_acc',300, ...
    'deltaE',0.7,'a_i',50e-6,'binRange',15,'nBins',1024);

fields=fieldnames(params);

fid=fopen(paramsFile);
lineCtr=1;
while 1
    line = fgetl(fid);
    if ~ischar(line), break, end
    if( (isempty(strfind(line,'#')) ) & ~isempty(line) )
        lines_in{lineCtr}=line;
        lineCtr=lineCtr+1;
    end;
end;
fclose(fid);
for j=1:length(lines_in)
    for k=1:length(fields)
        z=regexp(lines_in{j},fields{k},'split');
        if( length(z)>1 )
            zz=strtrim(z{2});
            switch fields{k}
                case {'outputDir','imageFile','modelFile','maskFile','rotationsFile','listFormat'} % string input
                    params=setfield(params,char(fields(k)),strtrim(zz));
                otherwise % number input
                    params=setfield(params,char(fields(k)),str2num(strtrim(zz)));
            end;
        end;
    end;
end;


%% 
function R=readRotationsFile(inref);
% read rotation matrices from an ASCII file
%
% function outref=readRotationsFile(inref);

fid=fopen(inref,'r');
A=fscanf(fid,'%f');
fclose(fid);
nRotations=size(A,1)./12;
inds=A(1:4:end);
A=A(setdiff(1:length(A),1:4:length(A)));
A=reshape(A,3,nRotations.*3);
R=reshape(A,3,3,nRotations);
for i=1:size(R,3)
    R(:,:,i)=R(:,:,i)';
end;

%% 
function outref=writeRotationsFile(R);
% write rotation matrices to an ASCII file
% 
% function outref=writeRotationsFile(R);

R_f=zeros(size(R),'single');
for i=1:size(R,3)
    R_f(:,:,i)=R(:,:,i)';
end;
RR=reshape(R_f,3,3*size(R_f,3));
temp=1:size(R,3);
temp=repmat(temp,3,1);
indexVector=reshape(temp,1,3*size(R,3));
fid=fopen('testR.txt','w');
fprintf(fid,'%7i\t%5.4f\t%5.4f\t%5.4f\n',cat(1,indexVector,RR));
fclose(fid);

%% 
function indsToUse=assignJobs(nIndices,nServers,serverID);
% calculate a vector of indices to share the work across servers
%
% function indsToUse=assignJobs(nIndices,nServers,serverID)

baseJobs=ceil(nIndices/nServers);
jobsPerServer=ones(1,nServers).*baseJobs;
jobsWithBase=cumsum(jobsPerServer);
startInds=jobsWithBase-baseJobs+1;
lastJobToUse=min([jobsWithBase(end) nIndices]);
jobsWithBase(end)=lastJobToUse;

indsToUse=[]; nJ=[];
for j=1:nServers
    indsToUse{j}=[startInds(j):jobsWithBase(j)];
    nJ(j)=length(indsToUse{j});
end;

indsToUse=indsToUse{serverID};

%%
function outref=nm(inref);
% inref: N-D vector
% outref: normalized inref 
% uses stripped-down versions of built-in functions
% function outref=nm(inref);

x=inref(:);
nans=isnan(x);
x(nans)=0;
n=sum(~nans,1);
m=sum(x,1)./n;
denom=max(n-1,1);
x0=x-m;
y=sum(abs(x0(~nans)).^2,1)./denom;
ns=(y.^0.5);
outref=(inref-m)./ns;

%%
function [k_2d,centerPixel]=getKs(imref,aPerPix);
%
% [k_2d,centerPixel]=getKs(imref,aPerPix);
if( size(imref,1)==1 & size(imref,2)==1 )
    imref=zeros(imref,imref);
end;

nPix=size(imref,1);
centerPixel=floor((nPix./2)+1);
k_2d=rrj(imref)./aPerPix;


%%
function outref=rrj(inref);
% get the k-space coordinates 
% inref is any matrix that is the size of the k-space
%
% function outref=rrj(inref);

dims=[size(inref,1) size(inref,2) size(inref,3)];
nPix=size(inref,1);
cp=floor((nPix./2)+1);
x=[1:nPix]-cp;

X=zeros(dims(1),dims(2),dims(3));
for i=1:dims(3)
    X(:,:,i)=repmat(x,dims(1),1);
end;

if( dims(3)>1 )
    Y=permute(X,[2 1 3]);
    Z=permute(X,[3 1 2]);
    R=sqrt(X.^2+Y.^2+Z.^2);
    outref=R./(2.*R(1,cp,cp));
else
    Y=permute(X,[2 1]);
    R=sqrt(X.^2+Y.^2);
    outref=R./(2.*R(cp,1));
end;

%%
function outref=cropForFFT(inref);
% 
% function outref=cropForFFT(varargin);

dim=max(size(inref));
fprintf('old dim is %d pixels...',dim);
while 1
    f=factor(dim);
    if( ~sum(f>3) )
        break;
    end;
    dim=dim-1;
end;

outref=cutj(inref,[dim,dim]);
fprintf('new dim is %d pixels.\n',dim);

%%
function outref=ftj(inref);
% forward FFT
% function outref=ftj(inref);

nPix=prod(size(inref));
inref_F=fftshift(fftn(ifftshift(inref)))./sqrt(nPix);
outref=inref_F;

%%
function outref=iftj(inref);
% inverse FFT
% function outref=iftj(inref);

nPix=prod(size(inref));
inref(find(isnan(inref)==1))=0;
outref=fftshift(real(ifftn(ifftshift(inref)))).*sqrt(nPix);

%%
function outref=cutj(inref,varargin);
% crop an image
% only called by cropForFFT
% function outref=cutj(inref,varargin);

nDims=length(size(inref));
for i=1:nDims
    oldDim(i)=size(inref,i);
    newDim(i)=varargin{1}(i);
    dimL(i)=(newDim(i)>oldDim(i));
end;

centerPixOld=floor((size(inref)./2)+1);
for i=1:nDims
    if( dimL(i)==0 )
        oddOldFlag=mod(oldDim(i),2);
        if( oddOldFlag==1 )
            halfOldDim(i)=ceil(oldDim(i)./2);
        else
            halfOldDim(i)=oldDim(i)./2;
        end;
        edges{i}=ceil([centerPixOld(i)-newDim(i)./2 centerPixOld(i)+(newDim(i)./2)-1]);
    else
        edges{i}=[1 oldDim(i)];
    end;
end;
outIm=inref(edges{1}(1):edges{1}(2),edges{2}(1):edges{2}(2));
outref=outIm;


%%
function outref=extendj(inref,varargin);
% pad an image
%
% function outref=extendj(inref,varargin);

nDims=length(size(inref));
for i=1:nDims
    oldDim(i)=size(inref,i);
    newDim(i)=varargin{1}(i);
end;
padVal=varargin{end};

for i=1:nDims
    oddOldFlag=mod(oldDim(i),2);
    if( oddOldFlag==1 )
        halfOldDim(i)=ceil(oldDim(i)./2);
        halfNewDim(i)=floor(newDim(i)./2);
        centerPixOld(i)=halfOldDim(i);
        centerPixNew(i)=halfNewDim(i)+1;
    else
        halfOldDim(i)=oldDim(i)./2;
        halfNewDim(i)=newDim(i)./2;
        centerPixOld(i)=halfOldDim(i)+1;
        centerPixNew(i)=floor(halfNewDim(i)+1);
    end;
    edges{i}=[centerPixOld(i)-newDim(i)./2 centerPixOld(i)+(newDim(i)./2)-1];
end;
diffSize=newDim(1)-oldDim(1);
rowColInds={ [num2str(centerPixNew(1)-oldDim(1)./2) ':' num2str((centerPixNew(1)+oldDim(1)./2)-1)] , ...
    [num2str(centerPixNew(2)-oldDim(2)./2) ':' num2str((centerPixNew(2)+oldDim(2)./2)-1)] };
dummy=reshape(1:(newDim(1))*(newDim(2)),(newDim(1)),(newDim(2)));
eval(['rowColNums=dummy(' rowColInds{1} ',' rowColInds{2} ');']);

outref=single(ones(newDim(1),newDim(2)).*padVal);
outref(rowColNums)=inref;

%%
function [filterOut,imOut,psbg]=psdFilter(nfIm,varargin);
% [filterOut,imOut,psbg]=psdFilter(nfIm,varargin);
nSectors=[];
method='psd';
if( nargin>1 )
    method=varargin{1};
    if( nargin>2 )
        nSectors=varargin{2};
    end;
end;

nfIm=nfIm-mean(nfIm(:));

nPix=size(nfIm,1);
nfIm_F=abs(fftshift(fftn(ifftshift(nfIm)))).^2;
cp=floor((nPix./2)+1);
nfIm_F(cp,cp)=0;
psd=sqrt((nfIm_F)./(nPix.^2));

if( ~isempty(nSectors) )
    
    edgeSize_blend=21;
    % psd_center=smap.radialmeanIm(psd);
    [~,psd_center]=radialmeanj(psd,1);
    mask=rrj(psd).*size(psd,1);
    mask=(mask<=(edgeSize_blend./2));
    inds=find(mask==1);
    
    [~,psbg]=radialmeanj(abs(ftj(nfIm)),nSectors);
    
    sf=sum(psbg(inds))./sum(psd_center(inds));
    psbg(inds)=((psd_center(inds).*sf)+psbg(inds))./2;
    
    psbg(cp,cp)=1;
    filterOut=1./psbg;
    filterOut(cp,cp)=0;
    
    imOut=nm(iftj(ftj(nfIm).*filterOut));
    
else
    
    psbg=radialmeanIm(psd);
    cp=floor(size(nfIm,1)./2)+1;
    psbg(cp,cp)=1;
    filterOut=1./psbg;
    filterOut(cp,cp)=0;
    imOut=nm(iftj(ftj(nfIm).*filterOut));

end;

%%
function outref=radialmeanIm(imref);
%
% function outref=radialmeanIm(imref);
if( min(size(imref))==1 )
    edgeSize=ceil(length(imref)*2/sqrt(2));
    realR=imref;
    RRd=single(rrj(zeros(edgeSize,edgeSize)));
else
    RRd=single(rrj(imref));%(size(imref,1),size(imref,2),'freq'));
    realR=single(radialmeanj(imref));
end;

inc=(max(RRd(:)))./(length(realR)-1);
dummyR=[0:inc:max(RRd(:))]; 
outref=zeros(size(RRd));
for i=1:size(RRd,1)
    inds=find(isnan(RRd(i,:))==0);
    outref(i,inds)=interp1(dummyR,realR,RRd(i,inds),'linear');
end;

[ntfx2,ntfy2]=find(isnan(RRd)==1);
if( ~isempty(ntfx2) )
    edgeVal=realR(round(size(imref,1)/2)-1);
    for i=1:length(ntfx2)
        outref(ntfx2(i),ntfy2(i))=edgeVal;%mean(realR(2:3));
    end;
end;


%%
function [outref,outref_2d]=radialmeanj(imref,varargin);

sf=[];
if( nargin>2 )
    sf=varargin{2}; % smoothing factor to apply to sectors (if sectors are used)
end;

Npix=size(imref,1);
rCoord=rrj(imref).*Npix;
cp=floor(size(imref,1)./2)+1;
oddFlag=mod(size(imref,1),2);
if( oddFlag==1 )
    rBins=linspace(0,sqrt(2)./2,(size(imref,1).*sqrt(2)./2)+1);
else
    rBins=linspace(0,sqrt(2)./2,((size(imref,1)+1).*sqrt(2)./2)+1);
    rBins=rBins(1:end-1);
end;

rBins=rBins.*Npix;
rBins=rBins(1:2:end);

outref=zeros(1,length(rBins)-1,'single');
cpVal=imref(cp,cp);

outref=bindata(double(imref(:)),rCoord(:),rBins)';

outref(1)=cpVal;
outref_2d=[];

if( nargin>1 )
if( ~isempty(varargin{1}) )
n_tBins=varargin{1}; % # of theta bins
tBins=linspace(0,2.*pi,n_tBins); % check spacing near zero
t_inc=2*pi./n_tBins;
tBins=[0:t_inc:2*pi];

% % make second vector to bin:
R=single(rrj(imref)).*(floor(Npix./2)./0.5);

vec=-R(1,cp):R(end,cp);
[X,Y]=meshgrid(vec,vec);
Y=-Y;

% % % so instead we do this:
alpha_g=(double(atan((Y)./(X)))+pi/2)*2;
alpha_g(cp,cp)=-1;%nan;

rtBins{2}=rBins;
rtBins{1}=tBins;
rCoord=complex(alpha_g,rCoord);
rCoord=rCoord(:);

[test,y,y_new]=bindata(double(imref(:)),rCoord,rtBins,sf);

outref_2d=reshape(y_new,Npix,Npix);

outref_2d(cp,cp)=cpVal; % check this

end;
end;

%%
function [ym,yb,y_full] = bindata(y,x,xrg,varargin);

sf=[];
if( nargin>3 )
    if( ~isempty(varargin{1}) )
        sf=varargin{1};
    end;
end;

%function [ym,yb] = bindata(y,x,xrg)
%Computes ym(ii) = mean(y(x>=xrg(ii) & x < xrg(ii+1)) for every ii
%using a fast algorithm which uses no looping
%If a bin is empty it returns nan for that bin
%Also returns yb, the approximation of y using binning (useful for r^2
%calculations). Example:
%By Patrick Mineault
%Refs: https://xcorr.net/?p=3326
%      http://www-pord.ucsd.edu/~matlab/bin.htm

if( ~iscell(xrg) ) % 1-D output only
    [~,whichedge] = histc(x,xrg(:)');
    bins = min(max(whichedge,1),length(xrg)-1);
    xpos = ones(size(bins,1),1);
    ns = sparse(bins,xpos,1);
    ysum = sparse(bins,xpos,y);
    ym = full(ysum)./(full(ns));
    yb = ym(bins);
    y_full=[];
    
else
    
    x1=real(x);
    x2=imag(x);
    x1rg=xrg{1}(:);
    x2rg=xrg{2}(:);
    
    [~,whichedge1] = histc(x1,x1rg(:)');
    [~,whichedge2] = histc(x2,x2rg(:)');
    
    bins1 = min(max(whichedge1,1),length(x1rg)-1);
    bins2 = min(max(whichedge2,1),length(x2rg)-1);
    
    bins = (bins2-1)*(length(x1rg)-1)+bins1;
    
    xpos = ones(size(bins,1),1);
    ns = sparse(bins,xpos,1,(length(x1rg)-1)*(length(x2rg)-1),1);
    ysum = sparse(bins,xpos,y,(length(x1rg)-1)*(length(x2rg)-1),1);
    ym = full(ysum)./(full(ns));
    
    if( ~isempty(sf) )
        ym=sgolayfilt(double(ym),1,sf);
    end;
    y_full=ym(bins);
    yb = ym(bins);
    ym = reshape(ym,length(x1rg)-1,length(x2rg)-1);
%    pause;
    
end;

%%
function outref=meanj(inref,varargin);
% calculates mean with nan-awareness
% using stripped-down versions of built-in functions
% inref: N-D vector
%
% function outref=meanj(inref,varargin);

dim=1;
if( nargin>1 )
    dim=varargin{1};
end;
x=inref(:);

nans = isnan(x);
x(nans) = 0;
n = sum(~nans,1);
outref = sum(x,1)./n;


%%
function MTFout=approxMTF(inref,inputParams,varargin);
% 300 kV => ~0.5 MTF at f_nyq (Ruskin, Fig. 4); counting mode, 3 e/pix-s
% nb that MTF is only minimally changed by 5 e/pix-s (see between 3 eps and 7 eps in Fig. 5)
% also similar to Fig. 2 in McMullan 2014 (0.55 at 1 e/pix-s)
% this model works out correctly provided we use spatial frequencies that
% are treated as fraction of nyquist 
%
% function MTFout=approxMTF(sfs,inputParams,varargin);

binFactor=2;
if( nargin>2 )
    binFactor=varargin{1};
end;

[k_arb,cp]=getKs(size(inref,1),0.5);
k=k_arb;

a=inputParams(1);
b=inputParams(2);
c=inputParams(3);
alpha=inputParams(4);
beta=inputParams(5);

MTFout=(a./(1+alpha.*k.^2))+(b./(1+beta.*k.^2))+c;

if( binFactor ~= 1 )
    MTFout=resize_F(MTFout,binFactor,'fixedSize');%./binFactor;
end;


%%
function outref=resize_F(inref,sf,varargin);
% Fourier crop or pad to a new size; use 'newSize' to scale boundaries, too
% skip varargin to keep the original size;
% 
% outref=resize_F(inref,sf,varargin);

method='newSize';
if( nargin>2 )
	method=varargin{1};
end;

if( sf>1 ) % Fourier pad (upsample/zoom in):
    os=[size(inref,1) size(inref,2) size(inref,3)];
    finalSize=floor(min([size(inref,1) size(inref,2)]).*sf);
    inref_F=fftshift(fftn(ifftshift(inref)));
    inref_F_padded=extendj(inref_F,[finalSize,finalSize],0);
    outref=real(fftshift(ifftn(ifftshift(inref_F_padded))));

    outref=outref.*(sf).^2;
    switch method
        case 'fixedSize'
            outref=cutj(outref,[os(1),os(2)]);
        case 'newSize'
            outref=outref;
        otherwise
            outref=outref;
    end;
    
else % Fourier crop (downsample/zoom out):
    os=[size(inref,1) size(inref,2)];
    finalSize=min([size(inref,1) size(inref,2)]);
    dsSize=finalSize.*sf;
    while( mod(dsSize,1)>1e-3 )
        finalSize=finalSize+1;
        dsSize=finalSize.*sf;
    end;
    disp(['will pad original image to ' num2str(finalSize) ' pixels...']);
    inref=single(extendj(inref,[finalSize,finalSize],inref(1,1)));
    ns=round([size(inref,1).*sf size(inref,2).*sf]);
    inref_F=fftshift(fftn(ifftshift(inref)));
    inref_F_cut=double(cutj(inref_F,[ns(1),ns(1)]));
    outref=real(fftshift(ifftn(ifftshift(inref_F_cut))));
    
    switch method
	case 'fixedSize'
    	    outref=extendj(cutj(outref,[os(1),os(2)]),[os(1),os(2)],mean(outref(:)));
	otherwise
	    outref=outref;
    end;
    	    
	outref=outref.*(sf.^2);
    
end;     

%%
function CTF=ctf(edgeSize);
% replace the constants with an input structure for the microscope
% function CTF=ctf(edgeSize);

global params % input parameters

[Cs,Cc,V_acc,deltaE,a_i]=deal(params.Cs,params.Cc,params.V_acc, ...
    params.deltaE,params.a_i);
[df,pixelSize]=deal(params.defocus,params.aPerPix);

df1=df(1).*1e-9;
df2=df(2).*1e-9;
alpha_ast=df(3);

pixSize=pixelSize*1e-10;
N=edgeSize;
dummyIm=ones(N,N,'single');
df=df*1e-9;

cc=def_consts();
m_er=cc.m_e+cc.q_e.*V_acc./(cc.c_v.^2);
lambda = cc.h/sqrt(cc.q_e*V_acc*cc.m_e*(cc.q_e/cc.m_e*V_acc/cc.c_v^2 + 2 ));

[k_2d,cp]=getKs(dummyIm,pixelSize);

if( alpha_ast~=0 )

R=single(rrj(dummyIm)).*(floor(N./2)./0.5);
vec=-R(1,cp):R(end,cp);

[X,Y]=meshgrid(vec,vec);
Y=-Y;

gIm=acos(repmat(vec,size(R,1),1)./R);
gIm=atan(Y./X);

alpha_g=zeros(N,N);
for i=1:N
    for j=1:N
        tVal=atan(abs(Y(i,j))./abs(X(i,j)));
        if( (X(i,j)>=0)&&(Y(i,j)>=0) )
            alpha_g(i,j)=tVal;
        elseif( (X(i,j)<0)&&(Y(i,j)>=0) )
            alpha_g(i,j)=pi-tVal;
        elseif( (X(i,j)<0)&&(Y(i,j)<0) )
            alpha_g(i,j)=pi+tVal;
        elseif( (X(i,j)>=0)&&(Y(i,j)<0) )
            alpha_g(i,j)=2*pi-tVal;
        end;
        if( (X(i,j)==0)&&(Y(i,j)==0) )
            alpha_g(i,j)=0;
        end;
    end;
end;

ddf=df1-df2;
df_ast=0.5.*(df1+df2+ddf.*cos(2.*(alpha_g-alpha_ast)));

else
    df_ast=dummyIm.*df1;
end;

freq=k_2d.*1e10;
chi=(pi.*lambda.*freq.^2).*(df_ast-((Cs.*((lambda.^2)*(freq.^2))./2)));

w1=0;
w2=1-w1;
CTF=complex(w1.*sin(chi)-w2.*cos(chi),-w1.*cos(chi)-w2.*sin(chi));

% apply a coherence envelope:
termOne=-(((pi.*lambda.*(freq.^2).*Cc.*deltaE)./(4.*V_acc.*sqrt(log(2)))).^2);
termTwo=-((pi.*Cs.*(lambda.^2).*(freq.^3)-pi.*df_ast.*freq).^2).*(a_i.^2)/(log(2));
CTF=CTF.*exp(termOne).*exp(termTwo);


%%
function consts=def_consts();
% defines physical constants
%
% function consts=def_consts();

consts=[];
consts.m_e=9.109e-31;
consts.h=6.636e-34;
consts.q_e=1.602e-19;
consts.c_v=2.99792458e8;
consts.IC=(2.*consts.m_e./((consts.h./(2.*pi)).^2)).*consts.q_e;

%%
function zpOut=zp(numIn,N,varargin);
%
% function zpOut=zp(numIn,N,varargin);

padChar='0';
if( nargin>2 )
    padChar=varargin{1};
end;

if( ischar(numIn)==0 )
    numIn=num2str(numIn);
end;

while( length(numIn)<N )
    numIn=[padChar numIn];
end;
zpOut=numIn;


%%
function [map,rez]=mr(filename);
% modified version of ReadMRC (Fred Sigworth's program; File ID #27021,
% https://www.mathworks.com/matlabcentral/fileexchange/)
%
% The expected orientation is the one that matches what we expect to see after
% converting with mrc2tif, reading in with tr(), and then doing a flipud on
% the image. Here, the operation that yields the same image is a transpose.
%
% also truncates the reported resolution to %7.4f because we are reasonable
% people
%
% [map,rez]=mr(filename);

startSlice=1;
numSlices=inf;

if nargin<2
    test=0;
else
    test=varargin{1};
end;

% We first try for little-endian data
% f=fopen(filename,'r','ieee-le');
f=fopen(filename,'r','ieee-le','ISO-8859-1'); % jpr/042016
if f<0
    error(['in ReadMRC the file could not be opened: ' filename])
end;
% Get the first 10 values, which are integers:
% nc nr ns mode ncstart nrstart nsstart nx ny nz
a=fread(f,10,'*int32');
if abs(a(1))>1e5  % we must have the wrong endian data.  Try again.
    fclose(f);
    f=fopen(filename,'r','ieee-be');
    a=fread(f,10,'int32');  % convert to doubles
end;

if test
    a(1:10)
    disp(num2str(f));
end;
mode=a(4);

% Get the next 12 (entries 11 to 23), which are floats.
% the first three are the cell dimensions.
% xlength ylength zlength alpha beta gamma mapc mapr maps
% amin amax amean.
[b,cnt]=fread(f,12,'float32');
if test
   b
   disp(num2str(f));
end;

% b(4,5,6) angles
mi=b(10); % minimum value
ma=b(11); % maximum value
av=b(12);  % average value

% s.rez=double(b(1)); % cell size x, in A.
% s.rez=double(b(3)); % cell size x, in A.
s.rez=double(b(1))./double(a(1)); % % 081116/jpr

% get the next 30, which brings us up to entry no. 52.
[c,cnt]=fread(f,30,'*int32');
if test 
    c(1:3)
    disp(num2str(f)) 
end;
% c(2) is the extended header in bytes.

% the next two are supposed to be character strings.
[d,cnt]=fread(f,8,'*char');
d=d';
s.chars=d;
if test
    d  
    disp(num2str(f));
end;

% Two more ints...
[e,cnt]=fread(f,2,'*int32');
if test 
    e 
    disp(num2str(f));
end;

% up to 10 strings....
ns=min(e(2),10);
for i=1:10
	[g,cnt]=fread(f,80,'char');
	str(i,:)=char(g)';
end;
s.header=str(1:ns,:);

% Get ready to read the data.
s.nx=double(a(1));
s.ny=double(a(2));
s.nz=double(a(3));

switch mode
    case 0
        string='*uint8';
        pixbytes=1;
    case 1
        string='*int16';
        pixbytes=2;
    case 2
        string='*float32';
        pixbytes=4;
    case 6
        string='*uint16';
    otherwise
        error(['ReadMRC: unknown data mode: ' num2str(mode)]);
        string='???';
        pixbytes=0;
end;

if(c(2)>0)
    if test
        disp(num2str(f));
    end;
    [ex_header,cnt]=fread(f,c(2),'char');   
    disp(['Read extra header of ',num2str(c(2)),' bytes!'])
end

skipbytes=0;
nz=s.nz;
if startSlice>0
    if test
        disp(num2str(f));
    end;
    skipbytes=(startSlice-1)*s.nx*s.ny*pixbytes;
    fseek(f,skipbytes,'cof');
    nz=min(s.nz-(startSlice-1),numSlices);
end;

ndata=s.nx * s.ny * nz;
if test
    disp(num2str(f));
    string
    ndata
end;

[map,cnt]=fread(f,ndata,string);
fclose(f);

if cnt ~= ndata
    error('ReadMRC: not enough data in file.');
end;
map=reshape(map,s.nx,s.ny,nz);

rez=str2num(sprintf('%7.4f',s.rez));
newMap=zeros(size(map,2),size(map,1),size(map,3),'single');
for i=1:size(map,3);
    newMap(:,:,i)=map(:,:,i)';
end;

map=newMap;


%%
function mw(map,filename,rez);
% modified version of ReadMRC (Fred Sigworth's program; File ID #27021,
% https://www.mathworks.com/matlabcentral/fileexchange/) that includes
% WriteMRCHeader (also by Fred Sigworth).
% Transposes the image before writing. This undoes the transpose at
% read-in that corrects the reader's orientation swap. At the end of the
% day, reading in an .mrc file and writing it to a new file (no transforms
% at the command line or in matlab) generates an identical copy according
% to the fiji reader.
%
% % Write out a 2D image or a 3D volume as an MRC map file, for example for viewing in
% % Chimera.  'map' is the 3D array, rez is the voxel size in angstroms.
% %
% % fixed for 2D output as well.  fs 28 Aug 07
% % 
% % % Test program: create an ellipsoid and store it as a map file.
% %   [x y z]=ndgrid(-32:31);
% %   m=(x.^2+(y*1.5).^2+z.^2)>20^2;
% %   WriteMRC(m,1,'maptest.mrc');
% % 
% function mw(map,filename,rez);
% %   
% % writes an MRC Header (Sigworth's program)
% % function handle=WriteMRCHeader(sizes,rez,filename,nim)
% % Write out the header of an MRC map file, and leave the file open,
% % returning the file handle, so that data can be written sequentially into
% % the file and then the file closed.  Data are written in little-endian style,
% % as float32 values.
% % If you want to write more images than are contained in map, give the
% % number in the optional nim argument.
% %
% % Example: write out 10,000 images.
% %     images=randn(64,64,1000);
% %     f=WriteMRCHeader(images,2.8,'test.mrc',10000);
% %     fwrite(f,images,'float32');
% %     for i=2:10
% %         images=randn(64,64,1000);
% %         fwrite(f,images,'float32');
% %     end;
% %     fclose(f);
% 
% % Files are always written in little-ended format.
% % Figure out if we have a little-ended machine.

newMap=zeros(size(map,2),size(map,1),size(map,3),'single');
for i=1:size(map,3);
    newMap(:,:,i)=map(:,:,i)';
end;
map=newMap;

q=typecast(int32(1),'uint8');
machineLE=(q(1)==1);  % true for little-endian machine
hdr=int32(zeros(256,1));
sizes=size(map);

if numel(sizes)<3
    sizes(3)=1;
end;
if nargin >3
    sizes(3)=nim;
end;

% Get statistics
map=reshape(map,numel(map),1);  % convert it into a 1D vector
theMean=mean(map);
theSD=std(map);
theMax=max(map);
theMin=min(map);

hdr(1:3)=sizes; % number of columns, rows, sections
hdr(4)=2;  % mode: real, float values
hdr(8:10)=hdr(1:3);  % number of intervals along x,y,z
hdr(11:13)=typecast(single(single(hdr(1:3))*rez),'int32');  % Cell dimensions
hdr(14:16)=typecast(single([90 90 90]),'int32');   % Angles
hdr(17:19)=(1:3)';  % Axis assignments
hdr(20:22)=typecast(single([theMin theMax theMean]'),'int32');
hdr(23)=0;  % Space group 0 (default)
if machineLE
    hdr(53)=typecast(uint8('MAP '),'int32');
    hdr(54)=typecast(uint8([68 65 0 0]),'int32');  % LE machine stamp.
else
    hdr(53)=typecast(uint8(' PAM'),'int32');  % LE machine stamp, for writing with BE machine.
    hdr(54)=typecast(uint8([0 0 65 68]),'int32');
end
hdr(55)=typecast(single(theSD),'int32');

f=fopen(filename,'w','ieee-le','ISO-8859-1'); % jpr/042016
count1=fwrite(f,hdr,'int32');
count2=fwrite(f,map,'single');
fclose(f);


%%
