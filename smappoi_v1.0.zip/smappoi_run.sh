#! /bin/sh
# usage is: ./smappoi_run.sh <paramsFile>
# e.g.,  ./smappoi_run.sh sample_calcSP.par
# e.g.,  ./smappoi_run.sh sample_searchImage.par

paramsFile=$1

cacheDir=$PWD/mcrCache/mcr_cache_root

fxnToRun=(`grep 'function' $paramsFile | sed 's/^.* //'`)
nToRun=(`grep 'nCores' $paramsFile | sed 's/^.* //'`)


numDone=0;
currentNum=1;
while [[ $currentNum -le $nToRun ]]
do
	echo starting on process $currentNum ...
	timeStamp=(`date +%s`)
	r=$RANDOM
	export MCR_CACHE_ROOT=$cacheDir.$currentNum-$timeStamp-$r
	$fxnToRun $paramsFile $currentNum > /dev/null &
	rm -rf $cacheDir.$jobNum-$timeStamp-$r
	((currentNum=$currentNum+1));
done

echo 

